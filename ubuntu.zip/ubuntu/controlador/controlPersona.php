<?php 
include_once('../modelo/clasePersona.php');


function guardar()
{
	if( (isset($_POST['txtNombre'])) && (isset($_POST['txtPaterno'])) && (isset($_POST['txtMaterno'])) && (isset($_POST['txtEdad'])))
	{
		$obj= new Persona();
		$obj->setNombre($_POST['txtNombre']);
		$obj->setPaterno($_POST['txtPaterno']);
		$obj->setMaterno($_POST['txtMaterno']);
		$obj->setEdad($_POST['txtEdad']);
		if ($obj->guardar())
			echo "Persona Guardada..!!!";
		else
			echo"Error al guardar la Persona";
	}
	else{
		echo"son  obligatorio los campos..!!!";
	}
}


 switch($_POST['botones'])
  {
	
	case "Guardar":{
    guardar();
	}break;
  }


 ?>